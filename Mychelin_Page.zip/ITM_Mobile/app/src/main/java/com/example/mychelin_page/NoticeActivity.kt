package com.example.mychelin_page

class NoticeActivity {
}
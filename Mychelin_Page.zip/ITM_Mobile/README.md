# ITM_Mobile
2024 ITM Mobile Programming module Assignment

- Min API  : 29 (Android 10)
- Device   : Nexus 4 API 30


## Pages

- P_01 (act) Log_in
- P_02 (act) Registration
- P_03 (act) Main
- P_04 (frg) Home
- P_05 (frg) Menu
- P_06 (frg) Search
- P_07 (frg) Booking
- P_08 (frg) Profile
- P_09 (frg) OCR
- P_10 (frg) Receit
- P_11 (frg) Ranking
- P_12 (frg) Notice
- p_13 (act) Settings


## Domain

- D_01 map
- D_02 payment
- D_03 GPS
- D_04 local data access
- D_05 Camera access
- D_06 server
